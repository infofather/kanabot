#!/bin/bash
cd ~/httpdocs/bot
/usr/local/go/bin/go build -o bot ./cmd/bot
