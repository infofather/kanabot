# Telegram Bot in Go with Webhook for Plesk + Git Deploy

## Features

- Webhook-based Telegram bot
- Git-based deployment via Plesk
- Simple Go structure
- Post-deploy build script

## Setup

1. Add your `BOT_TOKEN` to environment variables.
2. Configure webhook with your domain:
```
curl -X POST "https://api.telegram.org/bot<YOUR_TOKEN>/setWebhook?url=https://yourdomain.com/webhook"
```
3. Deploy to Plesk via Git and run build script.
